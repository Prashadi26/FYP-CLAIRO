// server.js

import express from 'express';
import bodyParser from 'body-parser';
import twilio from 'twilio';
import cors from 'cors';
import { env } from 'node:process'; // Import dotenv to load environment variables
import { createClient } from '@supabase/supabase-js';
import cron from 'node-cron';




const app = express();
const port = env.PORT || 5000;

// Middleware
app.use(cors());
app.use(bodyParser.json());

// Twilio credentials
const accountSid = 'AC84b4431a61ec2cc77e991e13eddcd3d9'; // Use environment variables for Twilio credentials
const authToken = '084c3b1f86ba0d5706ea8d372613377a'; 
const client = twilio(accountSid, authToken);

// Use environment variables for Supabase credentials
const supabaseUrl = 'https://ozqeuffkgiiqvntfypmq.supabase.co';
const supabaseKey = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Im96cWV1ZmZrZ2lpcXZudGZ5cG1xIiwicm9sZSI6ImFub24iLCJpYXQiOjE3MzUyMTYyODQsImV4cCI6MjA1MDc5MjI4NH0.Ciwb8mNvzrcKzekFDWi8YujXt4t5zvIQrhHjkZi1Ssg';

const supabase = createClient(supabaseUrl, supabaseKey);


// Endpoint to send WhatsApp message
app.post('/send-message', (req, res) => {
    const { phoneNumber, message } = req.body;

    client.messages.create({
        from: 'whatsapp:+14155238886', // Twilio Sandbox Number
        to: `whatsapp:${phoneNumber}`,
        body: message,
    })
    .then(message => res.json({ success: true, messageId: message.sid }))
    .catch(error => res.status(500).json({ success: false, error: error.message }));
});

// Endpoint to receive incoming messages (Webhook)
app.post('/incoming', (req, res) => {
    const twiml = new twilio.twiml.MessagingResponse();
    const incomingMsg = req.body.Body; // Get the incoming message text

    console.log(`Received message: ${incomingMsg}`);

    // Respond back if needed
    twiml.message(`You said: ${incomingMsg}`);
    res.writeHead(200, { 'Content-Type': 'text/xml' });
    res.end(twiml.toString());
});

// Automated process to check for due tasks every day at 7 AM
// Automated process to check for due tasks every day at 7 AM
//cron.schedule('0 7 * * *', async () => {
    cron.schedule('38 21 * * *', async () => {
    
    try {
        const currentDateTime = new Date();

        // Calculate reminder deadline (1 day before due date)
        const reminderDateTime = new Date(currentDateTime);
        reminderDateTime.setDate(currentDateTime.getDate() + 1);

        // Query to find tasks due in the next day and gather all required details
        const { data: tasks, error } = await supabase
            .from('client_case_task')
            .select(`
                client_case_task,
                deadline,
                client_case_id,
                client_case (
                    case_id,
                    client_id,
                    cases (case_no),
                    clients (contact_no)
                )
            `)
            .gte('deadline', currentDateTime.toISOString())
            .lte('deadline', reminderDateTime.toISOString());

        if (error) {
            console.error('Error fetching tasks:', error);
            return;
        }

        // Loop through each task and send reminders
        for (const task of tasks) {
            const { client_case_task, deadline, client_case } = task; // Use correct field names
            const { case_id, client_id, cases, clients } = client_case; // Destructure correctly

            const caseNo = cases.case_no; // Extract case number
            const contactNo = clients.contact_no; // Extract contact number

            const messageBody = `
                Reminder: The task "${client_case_task}" related to case "${caseNo}" is due tomorrow (${deadline}).
            `;

            // Send WhatsApp message using Twilio
            await client.messages.create({
                from: 'whatsapp:+14155238886', // Twilio Sandbox Number
                to: `whatsapp:${contactNo}`,
                body: messageBody,
            });

            console.log(`Reminder sent for task "${client_case_task}" related to case "${caseNo}".`);
        }
    } catch (error) {
        console.error('Error in automated reminder process:', error);
    }
});


// Start server
app.listen(port, () => {
    console.log(`Server running on port ${port}`);
});
